#
# TABLE STRUCTURE FOR: disposisi
#

DROP TABLE IF EXISTS `disposisi`;

CREATE TABLE `disposisi` (
  `id_disposisi` tinyint(4) NOT NULL AUTO_INCREMENT,
  `tujuan` varchar(250) NOT NULL,
  `isi_disposisi` mediumtext NOT NULL,
  `sifat` varchar(100) NOT NULL,
  `batas_waktu` date NOT NULL,
  `catatan` varchar(250) NOT NULL,
  `id_surat` int(11) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_disposisi`),
  KEY `id_surat` (`id_surat`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `disposisi` (`id_disposisi`, `tujuan`, `isi_disposisi`, `sifat`, `batas_waktu`, `catatan`, `id_surat`, `id_user`) VALUES (3, 'Kelurahan Balekambang', 'ini penting', 'penting', '2019-08-03', 'ini gila penting', 15, 2);


#
# TABLE STRUCTURE FOR: instansi
#

DROP TABLE IF EXISTS `instansi`;

CREATE TABLE `instansi` (
  `id_instansi` tinyint(1) NOT NULL,
  `title` varchar(20) NOT NULL,
  `institusi` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `kepsek` varchar(50) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `website` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `logo` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `instansi` (`id_instansi`, `title`, `institusi`, `nama`, `status`, `alamat`, `kepsek`, `nip`, `website`, `email`, `logo`, `id_user`) VALUES (1, 'Apps Manajemen Surat', 'Dinas Shitposting Informatika', 'Apps Manajemen Surat', 'Terakreditasi F', 'Bikini Bottom', 'Rechtweez', '12164440', 'https://rechtweez.com', 'rechtweezjr@gmail.com', 'nfs2.png', 0);


#
# TABLE STRUCTURE FOR: klasifikasi
#

DROP TABLE IF EXISTS `klasifikasi`;

CREATE TABLE `klasifikasi` (
  `id_klasifikasi` int(5) NOT NULL AUTO_INCREMENT,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `uraian` mediumtext NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_klasifikasi`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `klasifikasi` (`id_klasifikasi`, `kode`, `nama`, `uraian`, `id_user`) VALUES (2, 'A', 'Pendidikan', 'Pendidikan Sekolah Menengah Kejuruan', 3);
INSERT INTO `klasifikasi` (`id_klasifikasi`, `kode`, `nama`, `uraian`, `id_user`) VALUES (3, 'B', 'Sarana', 'Bangunan Sekolah dan Sarana Pendukung Lainnya', 3);
INSERT INTO `klasifikasi` (`id_klasifikasi`, `kode`, `nama`, `uraian`, `id_user`) VALUES (4, 'C', 'Kurikulum', 'Kurikulum 2016', 3);
INSERT INTO `klasifikasi` (`id_klasifikasi`, `kode`, `nama`, `uraian`, `id_user`) VALUES (5, 'D', 'Kegiatan', 'Ekstrakurikuler', 3);
INSERT INTO `klasifikasi` (`id_klasifikasi`, `kode`, `nama`, `uraian`, `id_user`) VALUES (6, 'E', 'Administrasi', 'Administrasi Keuangan', 3);
INSERT INTO `klasifikasi` (`id_klasifikasi`, `kode`, `nama`, `uraian`, `id_user`) VALUES (8, 'F', 'Pencurry', 'Dinas Pencurry Indonesia', 2);


#
# TABLE STRUCTURE FOR: sett
#

DROP TABLE IF EXISTS `sett`;

CREATE TABLE `sett` (
  `id_sett` tinyint(1) NOT NULL,
  `surat_masuk` tinyint(2) NOT NULL,
  `surat_keluar` tinyint(2) NOT NULL,
  `referensi` tinyint(2) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_sett`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: surat_keluar
#

DROP TABLE IF EXISTS `surat_keluar`;

CREATE TABLE `surat_keluar` (
  `id_surat` int(10) NOT NULL AUTO_INCREMENT,
  `no_agenda` int(10) NOT NULL,
  `tujuan` varchar(250) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `isi` mediumtext NOT NULL,
  `kode` varchar(30) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_catat` date NOT NULL,
  `file` varchar(250) NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_surat`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `surat_keluar` (`id_surat`, `no_agenda`, `tujuan`, `no_surat`, `isi`, `kode`, `tgl_surat`, `tgl_catat`, `file`, `keterangan`, `id_user`) VALUES (1, 1, 'Boating School', 'R/001/422-MTSN6/II/2019', 'ini paling penting', '421.3', '2019-08-02', '2019-08-02', '3e0b1196fd119a28e1de60852c8ae699.jpg', 'ini juga penting', 2);
INSERT INTO `surat_keluar` (`id_surat`, `no_agenda`, `tujuan`, `no_surat`, `isi`, `kode`, `tgl_surat`, `tgl_catat`, `file`, `keterangan`, `id_user`) VALUES (2, 2, 'Kelurahan Batu Ampar', 'R/004/422-MTSN6/II/2019', 'ini penting gila coy', '421.5', '2019-08-05', '2019-08-05', 'IMG_20171210_180945_246.jpg', 'penting banget tolong', 3);


#
# TABLE STRUCTURE FOR: surat_masuk
#

DROP TABLE IF EXISTS `surat_masuk`;

CREATE TABLE `surat_masuk` (
  `id_surat` int(10) NOT NULL AUTO_INCREMENT,
  `no_agenda` int(10) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `asal_surat` varchar(250) NOT NULL,
  `isi` mediumtext NOT NULL,
  `kode` varchar(30) NOT NULL,
  `indeks` varchar(30) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_diterima` date NOT NULL,
  `file` varchar(250) NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_surat`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `surat_masuk` (`id_surat`, `no_agenda`, `no_surat`, `asal_surat`, `isi`, `kode`, `indeks`, `tgl_surat`, `tgl_diterima`, `file`, `keterangan`, `id_user`) VALUES (14, 1, 'R/001/422-MTSN6/II/2019', 'Bikini Bottom', 'ini penting 1', '421.3', 'Ini juga penting', '2019-08-01', '2019-08-02', 'contoh_pengiriman_dokumen_kemendikbud-11.jpg', 'Bikini Bottom', 2);
INSERT INTO `surat_masuk` (`id_surat`, `no_agenda`, `no_surat`, `asal_surat`, `isi`, `kode`, `indeks`, `tgl_surat`, `tgl_diterima`, `file`, `keterangan`, `id_user`) VALUES (15, 2, 'R/002/422-MTSN6/II/2019', 'Rock Bottom', 'ini penting 2', '421.3', 'ini penting', '2019-08-01', '2019-08-02', '9839719a428de226669af5df36e78b8b.jpg', 'Rock Bottom', 2);
INSERT INTO `surat_masuk` (`id_surat`, `no_agenda`, `no_surat`, `asal_surat`, `isi`, `kode`, `indeks`, `tgl_surat`, `tgl_diterima`, `file`, `keterangan`, `id_user`) VALUES (17, 3, 'R/003/422-MTSN6/II/2019', 'Chum Bucket', 'ini penting 3', '421.3', 'ini penting', '2019-08-01', '2019-08-05', 'Screenshot_2017-12-27-13-14-43-27.png', 'Chum Bucket', 2);


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` tinyint(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(35) NOT NULL,
  `password` varchar(35) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `level` enum('Superadmin','Admin','Disposisi') NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `nip`, `level`) VALUES (2, 'fiqisulaiman', '32c012243b0c0819734672baaf788dc8', 'Fiqi Sulaiman', '12164440', 'Superadmin');
INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `nip`, `level`) VALUES (3, 'hokyaje', '8841158be9e25bd52b617dda47ee06b9', 'Muhammad Hoky Sumardi', '1216666', 'Admin');
INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `nip`, `level`) VALUES (4, 'pakhendro', '1adb72e1785b2c416433e36e79faac04', 'Hendro Mulyono', '12165757', 'Disposisi');


